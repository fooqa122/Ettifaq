ETTIFAQ Showcase v4 — Full coaching staff

This update replaces the team section with the 15 staff portraits, names, and roles visible in the user-provided Ettifaq technical-staff poster.
Portrait crops are embedded directly into index.html, so only one file needs to be uploaded to GitHub Pages.
The club-logo page from the previous showcase is preserved.

To update the existing GitHub Pages site:
1. Open https://github.com/fooqa122/Ettifaq
2. Open index.html and choose Edit, or use Add file > Upload files.
3. Replace the old index.html with this one, then commit changes.
4. Wait for GitHub Pages to redeploy and refresh the site.

The staff list is transcribed from the supplied image and should be checked with the club before an official presentation. This is a fan-made showcase, not an official club app.
