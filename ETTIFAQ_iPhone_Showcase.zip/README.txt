ETTIFAQ — Mobile showcase prototype

This is a responsive, clickable web prototype designed to be demonstrated on an iPhone.
It is not a native iOS app and it does not connect to live scores, official news, or standings.
All match/team content is placeholder content and is labelled accordingly.

Quickest way to show it on an iPhone:
1. Upload index.html to a GitHub repository.
2. In the repository, open Settings > Pages.
3. Choose Deploy from a branch, select main and /(root), then Save.
4. Open the published Pages URL on iPhone Safari.
5. Use Share > Add to Home Screen if you want an app-like icon.

A public link requires enabling GitHub Pages. Do not add private API keys to this prototype.
Before presenting as an official club product, obtain any required permission for official marks and branding.
